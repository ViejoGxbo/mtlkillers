// MTLKILLERS — background.js
// Coordina entre la app HTML y las páginas de Sodimac

// Escuchar mensajes externos desde la app HTML (GitHub Pages)
chrome.runtime.onMessageExternal.addListener(function(request, sender, sendResponse) {

  if (request.action === 'ping') {
    sendResponse({ success: true, version: '1.0' });
    return true;
  }

  if (request.action === 'scrape') {
    var url = request.url;
    if (!url) {
      sendResponse({ success: false, error: 'URL requerida' });
      return true;
    }

    // Usar fetch directo desde el background (sin CORS gracias a host_permissions)
    fetch(url)
      .then(function(res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.text();
      })
      .then(function(html) {
        var rx = /<script[^>]+id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/i;
        var m = html.match(rx);
        if (!m) throw new Error('No se encontró __NEXT_DATA__ en el HTML');
        
        var txt = m[1].trim();
        if (!txt) throw new Error('NEXT_DATA está vacío');
        if (txt === 'undefined') throw new Error('NEXT_DATA dice literalmente "undefined"');
        
        try {
          var nd = JSON.parse(txt);
          var result = parseProductData(nd, url, html);
          sendResponse({ success: true, data: result });
        } catch(e) {
          sendResponse({ success: false, error: 'JSON_PARSE_ERR: ' + e.message + ' (Starts with: ' + txt.substring(0,20) + ')' });
        }
      })
      .catch(function(err) {
        sendResponse({ success: false, error: 'FETCH_ERR: ' + err.message });
      });

    return true; // Mantener canal abierto para respuesta async
  }
});

// ── PARSER (igual que en la app HTML) ────────────────────

function isSlug(s) {
  if (!s || typeof s !== 'string') return true;
  return /^[a-z0-9]+(-[a-z0-9]+){3,}$/i.test(s.trim()) || s.trim().length < 4;
}

function bestName() {
  for (var i = 0; i < arguments.length; i++) {
    var v = arguments[i];
    if (v && typeof v === 'string' && !isSlug(v.trim())) return v.trim();
  }
  return null;
}

function dig(obj, key, d) {
  d = d || 0;
  if (d > 10 || !obj || typeof obj !== 'object') return null;
  if (key in obj) return obj[key];
  var ks = Object.keys(obj);
  for (var i = 0; i < ks.length; i++) {
    var r = dig(obj[ks[i]], key, d + 1);
    if (r !== null && r !== undefined) return r;
  }
  return null;
}

function fmtPrice(raw) {
  if (!raw && raw !== 0) return null;
  var n = parseFloat(String(raw).replace(/[^0-9.]/g, ''));
  if (isNaN(n)) return null;
  var parts = n.toFixed(2).split('.');
  return parseInt(parts[0], 10).toLocaleString('en-US') + (parts[1] && parts[1] !== '00' ? '.' + parts[1] : '');
}

function splitPrice(fmt) {
  if (!fmt) return { entero: '0', decimal: '.00' };
  var parts = String(fmt).replace(/[S\/\s]/g, '').split('.');
  return { entero: parts[0], decimal: parts[1] ? '.' + parts[1] : '.00' };
}

function parseProductData(nd, url, html) {
  var props = nd && nd.props;
  if (!props) throw new Error('Sin props en __NEXT_DATA__');
  var pp = props.pageProps || {};
  var p = pp.productData || null;
  if (!p) {
    var id = pp.initialData || {};
    p = (id.product && typeof id.product === 'object' ? id.product : null)
      || (pp.product && typeof pp.product === 'object' ? pp.product : null)
      || (id.data && id.data.product ? id.data.product : null)
      || dig(props, 'productData')
      || dig(props, 'product');
  }
  if (!p || typeof p !== 'object') throw new Error('Producto no encontrado');

  var esPeru = !!(pp.productData);

  // NOMBRE
  var nombre = bestName(
    p.displayName, p.productName, p.name, p.title,
    dig(p, 'displayName'), dig(p, 'productName'), dig(p, 'name')
  ) || 'Sin nombre';

  var sellerSkuId = null;
  try {
    if (p.variants && p.variants[0] && p.variants[0].offerings && p.variants[0].offerings[0]) {
      sellerSkuId = p.variants[0].offerings[0].sellerSkuId;
    }
  } catch(e) {}

  var skuTienda = null;
  if (esPeru) {
    try {
      var v0medias = p.variants[0].medias;
      for (var mi = 0; mi < v0medias.length; mi++) {
        var murl = v0medias[mi].url || '';
        var mMatch = murl.match(/sodimacPE\/([0-9a-zA-Z]+)[_\/]/i);
        if (mMatch && mMatch[1]) { skuTienda = mMatch[1]; break; }
      }
    } catch(e) {}
    if (!skuTienda) {
      var allJson = JSON.stringify(p);
      var mMatch2 = allJson.match(/sodimacPE\/([0-9a-zA-Z]+)[_\/]/i);
      if (mMatch2) skuTienda = mMatch2[1];
    }
  }

  var urlSkuMatch = (url||'').match(/\/articulo\/([0-9a-zA-Z]+)/i);
  var urlSku = urlSkuMatch ? urlSkuMatch[1] : null;
  var prodSku = p.sku || p.id || p.productId || dig(p, 'sku');

  var sku = String(sellerSkuId || skuTienda || urlSku || prodSku || '—');

  // MARCA
  var br = p.brand || dig(p, 'brand');
  var marca = (br && typeof br === 'object') ? (br.name || br.displayName || '—') : (br || p.brandName || dig(p, 'brandName') || '—');

  var esM2 = nombre.toLowerCase().includes('m2') || nombre.toLowerCase().includes('m²');

  // PRECIOS
  var precioNormal = null, precioCmr = null, precioAntes = null, descuento = null;
  var foundCmrType = false;
  
  if (esPeru && p.variants && p.variants[0] && Array.isArray(p.variants[0].prices)) {
    var pa = p.variants[0].prices;
    
    // Helper for m2
    function getVal(item) {
      if (esPeru && esM2 && item.unitPrice && item.unitPrice.price) return item.unitPrice.price;
      return Array.isArray(item.price) ? item.price[0] : item.price;
    }

    // First pass: look for exact types
    for (var i = 0; i < pa.length; i++) {
      var item = pa[i];
      var val = getVal(item);
      if (item.type === 'normalPrice' || item.type === 'internetPrice' || item.type === 'regularPrice') {
        if (!precioNormal) precioNormal = fmtPrice(val);
      }
      if (item.type === 'cmrPrice') {
        if (!precioCmr || parseFloat(val) < parseFloat(String(precioCmr).replace(/[^0-9.]/g,''))) precioCmr = fmtPrice(val);
        foundCmrType = true;
      }
      if (item.type === 'crossed' || item.crossed) {
        if (!precioAntes) precioAntes = fmtPrice(val);
      }
    }
    
    // Second pass: fallback for offerPrice if no cmrPrice found
    if (!foundCmrType) {
      var lowestOffer = null;
      for (var i = 0; i < pa.length; i++) {
        var item = pa[i];
        if (item.type === 'offerPrice') {
          var val = parseFloat(getVal(item));
          if (val && (!lowestOffer || val < lowestOffer)) lowestOffer = val;
        }
      }
      if (lowestOffer) precioCmr = fmtPrice(lowestOffer);
    }

    if (precioCmr === precioNormal) precioCmr = null;

    if (!precioAntes && precioCmr && precioNormal) {
      var rn = parseFloat(String(precioNormal).replace(/[^0-9]/g, '')); // now "49,90" becomes "4990"
      var rc = parseFloat(String(precioCmr).replace(/[^0-9]/g, ''));
      if (rn && rc && rn > rc) { precioAntes = precioNormal; descuento = '-' + Math.round(((rn - rc) / rn) * 100) + '%'; }
    }
    if (!descuento && p.variants[0].discountBadge) {
      var db = p.variants[0].discountBadge;
      descuento = String(db.label || db.text || db.value || '—');
    }

    var hasCmrBadge = false;
    try {
      var sb = JSON.stringify(p.variants[0].badges || []);
      if (sb.toUpperCase().includes('CMR')) hasCmrBadge = true;
    } catch(e) {}

    var cmrVis = (precioCmr && precioNormal) || (html && (html.includes('shade-red-text') || html.includes('cmr-price'))) || hasCmrBadge;
    if (!cmrVis && precioCmr) {
      if (!precioNormal) precioNormal = precioCmr;
      precioCmr = null;
    }
  } else {
    var pr = p.prices || p.price || p.pricing || dig(p, 'prices') || {};
    var rN = pr.normalPrice || pr.regularPrice || pr.listPrice || dig(p, 'normalPrice') || dig(p, 'regularPrice');
    var rC = pr.cmrPrice || pr.cardPrice || dig(p, 'cmrPrice') || dig(p, 'cardPrice');
    var rA = pr.previousPrice || pr.originalPrice || dig(p, 'previousPrice');
    var rD = pr.discountPercentage || pr.discount || dig(p, 'discountPercentage');
    precioNormal = fmtPrice(rN); precioCmr = fmtPrice(rC); precioAntes = fmtPrice(rA);
    if (rD) { var dn = parseInt(String(rD).replace(/\D/g, ''), 10); if (!isNaN(dn) && dn > 0) descuento = '-' + dn + '%'; }
    if (!descuento && rN && rA) {
      var a = parseInt(String(rN).replace(/\D/g, ''), 10), b = parseInt(String(rA).replace(/\D/g, ''), 10);
      if (a && b && b > a) descuento = '-' + Math.round(((b - a) / b) * 100) + '%';
    }
  }

  // STOCK
  var stock = 'DESCONOCIDO';
  if (esPeru) {
    if (p.isOutOfStock === false) stock = 'DISPONIBLE';
    else if (p.isOutOfStock === true) stock = 'AGOTADO';
  } else {
    var sv = p.availability || p.stockStatus || p.inStock || dig(p, 'availability');
    if (sv != null) {
      var ss = String(sv).toUpperCase();
      if (['TRUE', 'INSTOCK', 'IN_STOCK', 'AVAILABLE', 'DISPONIBLE', '1'].includes(ss)) stock = 'DISPONIBLE';
      else if (['FALSE', 'OUTOFSTOCK', 'OUT_OF_STOCK', 'AGOTADO', '0'].includes(ss)) stock = 'AGOTADO';
    }
  }

  // IMAGEN
  var imgUrl = null;
  if (esPeru) {
    try {
      imgUrl = p.variants[0].medias[0].url || null;
      if (imgUrl && imgUrl.includes('media.falabella.com'))
        imgUrl = imgUrl.replace(/\/public$/, '') + '/1500/1500/fit/public';
    } catch(e) {}
  } else {
    var imgs = p.images || p.media || dig(p, 'images');
    if (Array.isArray(imgs) && imgs.length > 0) {
      var fi = imgs[0];
      imgUrl = (typeof fi === 'string' ? fi : null) || fi.url || fi.src || fi.hdUrl || fi.largeUrl;
    } else if (imgs && typeof imgs === 'object') {
      imgUrl = imgs.hdUrl || imgs.largeUrl || imgs.url;
    }
    if (!imgUrl) imgUrl = p.imageUrl || p.image || dig(p, 'hdUrl') || dig(p, 'imageUrl');
    if (imgUrl) imgUrl = String(imgUrl).replace(/(_S|_M|_thumb|_small)/gi, '_L').replace(/\?.*$/, '');
  }

  var prin = precioCmr || precioNormal || 0;
  var sp = splitPrice(prin);
  return {
    nombre, sku, marca,
    precioNormal: precioNormal || '—',
    precioCmr: precioCmr || '—',
    precioAntes: precioAntes || '—',
    descuento: descuento || '—',
    precioEntero: sp.entero,
    precioDecimal: sp.decimal,
    stock, imgUrl, esM2
  };
}
