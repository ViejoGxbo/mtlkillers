// MTLKILLERS — content.js
// Se inyecta en páginas de Sodimac y extrae __NEXT_DATA__

(function() {
  // Escuchar mensajes del background
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === 'extractData') {
      try {
        var el = document.getElementById('__NEXT_DATA__');
        if (!el) {
          sendResponse({ success: false, error: 'No se encontró __NEXT_DATA__ en esta página' });
          return;
        }
        var nd = JSON.parse(el.textContent);
        sendResponse({ success: true, data: nd });
      } catch(e) {
        sendResponse({ success: false, error: e.message });
      }
      return true;
    }
  });
})();
